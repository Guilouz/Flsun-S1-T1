#!/bin/bash
FAN_MESG=/home/pi/mesg/fan_mesg
PRINT_CFG_LOCAL=/home/pi/printer_data/config/printer.cfg
PRINT_CFG_UPDATE=/home/pi/upgrade/config/printer.cfg
PRINT_CFG_TEMP=/home/pi/upgrade/printer.cfg_bak
FAN_MAX_POWER_VALUE_FILE=/home/pi/fan_max_power_value_file

FAN_MAX_POWER_LINE_LOCAL=""
FAN_MAX_POWER_LINE_UPDATE=""
FAN_MAX_POWER_LINE_CONTENT_LOCAL=""
FAN_MAX_POWER_LINE_CONTENT_UPDATE=""
FAN_MAX_POWER_VALUE_LOCAL=""
FAN_MAX_POWER_VALUE_UPDATE=""

if [ ! -f "$FAN_MESG" ]; then
	touch $FAN_MESG
else
	echo "" > $FAN_MESG
fi

look_fan_max_power()
{
	cfg_file=$1
	
	FAN_LINE=""
	FAN_MAX_POWER_LINE=""
	FAN_MAX_POWER_VALUE=""
	FAN_MAX_POWER_LINE_CONTENT=""
	
	sed '/#\*#/!s/#.*//' $cfg_file > $PRINT_CFG_TEMP   #�������ļ�ע��ȥ�����ض���

	FAN_LINE=`grep -P -n "\[\s*fan\s*\]" "$PRINT_CFG_TEMP" | cut -d':' -f1 | head -1` #��[fan]���к�
	if [ -z "$FAN_LINE" ]; then
		echo "FAN_LINE empty"                                  >>  $FAN_MESG
		exit
	else
	  echo "FAN_LINE not empty"                               >>  $FAN_MESG
	  linenum=0
	  while IFS= read -r line; do
		# ����к��Ƿ���ڻ������ʼ�к�
		if [ $(($linenum + 1)) -gt $FAN_LINE ]; then
		  # ����Ƿ����max_power
		  if [[ $line =~ max_power:[[:space:]]*([0-9]+\.[0-9]+) ]]; then
			FAN_MAX_POWER_LINE=$(($linenum + 1))
			FAN_MAX_POWER_VALUE=${BASH_REMATCH[1]}
			FAN_MAX_POWER_LINE_CONTENT=$line
			echo "FAN_MAX_POWER_LINE=$FAN_MAX_POWER_LINE"          >>  $FAN_MESG
			echo "FAN_MAX_POWER_VALUE=$FAN_MAX_POWER_VALUE"        >>  $FAN_MESG
			echo "$FAN_MAX_POWER_LINE_CONTENT"                      >>  $FAN_MESG 
		  fi
			# ����Ƿ�����[*]
		  if [[ $line =~ \[.*\] ]]; then
			  echo "linenum=$(($linenum + 1)) Found [*], stopping search."  	>>  $FAN_MESG
			  break
		  fi
		fi
		((linenum++))
	  done < "$PRINT_CFG_TEMP"
	fi
}
echo "---------------------------------"	                  	>>  $FAN_MESG
echo""															>>  $FAN_MESG
echo "look_fan_max_power $PRINT_CFG_LOCAL"	                  	>>  $FAN_MESG
look_fan_max_power $PRINT_CFG_LOCAL
if [ -z "$FAN_MAX_POWER_LINE" ]; then
    echo "FAN_MAX_POWER_LINE empty"                                  >>  $FAN_MESG
	exit
else
	echo "FAN_MAX_POWER_LINE not empty"                              >>  $FAN_MESG
	FAN_MAX_POWER_LINE_CONTENT_LOCAL=$FAN_MAX_POWER_LINE_CONTENT
	FAN_MAX_POWER_LINE_LOCAL=$FAN_MAX_POWER_LINE
	FAN_MAX_POWER_VALUE_LOCAL=$FAN_MAX_POWER_VALUE
	echo $FAN_MAX_POWER_VALUE_LOCAL > $FAN_MAX_POWER_VALUE_FILE
	echo "---------------------------------"	                  	>>  $FAN_MESG
	echo""															>>  $FAN_MESG
	echo "look_fan_max_power $PRINT_CFG_UPDATE"	                  	>>  $FAN_MESG
	look_fan_max_power $PRINT_CFG_UPDATE
	if [ -z "$FAN_MAX_POWER_LINE" ]; then
		echo "FAN_MAX_POWER_LINE empty"                               >>  $FAN_MESG
	else
		echo "FAN_MAX_POWER_LINE not empty"                               >>  $FAN_MESG
		FAN_MAX_POWER_LINE_CONTENT_UPDATE=$FAN_MAX_POWER_LINE_CONTENT
		FAN_MAX_POWER_LINE_UPDATE=$FAN_MAX_POWER_LINE
		FAN_MAX_POWER_VALUE_UPDATE=$FAN_MAX_POWER_VALUE
		sed -i "${FAN_MAX_POWER_LINE_UPDATE}s/^.*$/$FAN_MAX_POWER_LINE_CONTENT_LOCAL/" "$PRINT_CFG_UPDATE"
		if [ $? -eq 0 ]; then
			echo "Replace successfully  FILE-$PRINT_CFG_UPDATE  $FAN_MAX_POWER_LINE_UPDATE-$FAN_MAX_POWER_LINE_CONTENT_UPDATE Replaced $FAN_MAX_POWER_LINE_LOCAL-$FAN_MAX_POWER_LINE_CONTENT_LOCAL"  >>  $FAN_MESG
		else
			echo "Replace failed"  >>  $FAN_MESG
fi
	fi
fi
chmod 777 $PRINT_CFG_LOCAL
chmod 777 $PRINT_CFG_UPDATE
#rm -rf $PRINT_CFG_TEMP
