#!/bin/bash
rm /usr/lib/arm-linux-gnueabihf/dri -rf
rm /usr/lib/libarcsoft_face* -rf
rm /usr/share/doc -rf

cp /home/pi/reset_bak/c_helper.so /home/pi/reset_bak/klipper/klippy/chelper

python3 /home/pi/upgrade/del.py
sync
