 #!/bin/bash
TIME_LAPSE_FOLDER=/home/pi/flsun_func/time_lapse
TMP_FILE=$TIME_LAPSE_FOLDER/tmp.txt
TIME_LAPSE_LOG=$TIME_LAPSE_FOLDER/time_lapse_log.txt
BMP_COUNT=$TIME_LAPSE_FOLDER/bmp_count
BMP_FOLDER=$TIME_LAPSE_FOLDER/jpg
PHOTO_BLACK_OUT=/home/pi/savedVariables1.cfg

if [ ! -d "$BMP_FOLDER" ];then
	mkdir $BMP_FOLDER
fi

chmod 777 $BMP_FOLDER
	
if [ ! -f "$BMP_COUNT" ];then
	touch $BMP_COUNT
fi

if ! grep -q "plr_flag = True" "$PHOTO_BLACK_OUT"; then
	echo "10000" > $BMP_COUNT
  rm -rf $BMP_FOLDER/*
else
  sed -i 's/plr_flag = True/plr_flag = False/g' "$PHOTO_BLACK_OUT"
fi

chmod 777 $BMP_COUNT	
if [ ! -f "$TIME_LAPSE_LOG" ];then
	touch $TIME_LAPSE_LOG
else
	echo "" > $TIME_LAPSE_LOG
fi
chmod 777 $TIME_LAPSE_LOG	

/home/pi/klippy-env/bin/python $TIME_LAPSE_FOLDER/capturepicture



