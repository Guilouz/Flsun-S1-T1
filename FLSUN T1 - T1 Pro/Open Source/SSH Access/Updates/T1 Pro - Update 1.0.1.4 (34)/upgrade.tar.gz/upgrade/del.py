import os

def delete_files_in_directory(directory, extension):
    for filename in os.listdir(directory):
        path = os.path.join(directory, filename)
        if os.path.isfile(path) and path.endswith(extension):
            os.remove(path)
        elif os.path.isdir(path):
            delete_files_in_directory(path, extension)

delete_files_in_directory('/usr', '.a')
delete_files_in_directory('/home', '.a')

path_1 = r"/usr/lib/arm-linux-gnueabihf/openmpi/include"
path_2 = r"/home/pi/qt/arm_qt_environment/include"
path_3 = r"/home/pi/reset_bak"

if os.path.exists(path_1):
 delete_files_in_directory(path_1, '.h')
if os.path.exists(path_2):
 delete_files_in_directory(path_2, '.h')
if os.path.exists(path_3):
 delete_files_in_directory(path_3, '.c')
 delete_files_in_directory(path_3, '.h')
