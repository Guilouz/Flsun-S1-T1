#!/bin/bash

ONLINE_UPDATE_MESG=/home/pi/mesg/online_update_mesg
UPDATE_BAK_CACHE_DIR=/home/pi/update_bak_cache
UPDATE_BAK_DIR=/home/pi/update_bak
UPDATE_BAK_TMP_DIR=/home/pi/update_bak_tmp
UPDATE_SUCCESS_FLAG=/home/pi/update_success
UPDATE_FAIL_FLAG=/home/pi/update_fail
FILE1_UPDATE_DIR_LIB=/home/pi/qt/out_linux/lib
FILE_UUPDATE=/etc/uupdate
FILE_RESETBAK_GCODE_DIR=/home/pi/reset_bak/printer_data/gcodes/

#FILE1_UPDATE_CONFIG=/home/pi/upgrade/others/tuiconfig.ini

FILE_UPDATE_MAINSAIL=/home/pi/upgrade/mainsail
FILE1_UPDATE=/home/pi/upgrade/qt/out_linux
FILE2_UPDATE=/home/pi/upgrade/others/rc.local
FILE3_UPDATE=/home/pi/upgrade/config/printer.cfg
#d
FILE4_UPDATE=/home/pi/upgrade/flsun_func
FILE5_UPDATE=/home/pi/upgrade/klipper/delta.py
FILE6_UPDATE=/home/pi/upgrade/klipper/filament_motion_sensor.py
FILE7_UPDATE=/home/pi/upgrade/klipper/gcode_move.py
FILE8_UPDATE=/home/pi/upgrade/klipper/heaters.py
FILE9_UPDATE=/home/pi/upgrade/klipper/homing.py
FILE10_UPDATE=/home/pi/upgrade/others/cfg
FILE11_UPDATE=/home/pi/upgrade/others/webcamd
FILE12_UPDATE=/home/pi/upgrade/klipper/shaper_calibrate.py
FILE13_UPDATE=/home/pi/upgrade/klipper/shaper_defs.py
FILE14_UPDATE=/home/pi/upgrade/klipper/stepper_enable.py

FILE15_UPDATE=/home/pi/upgrade/klipper/toolhead.py
FILE16_UPDATE=/home/pi/upgrade/klipper/verify_heater.py
FILE17_UPDATE=/home/pi/upgrade/klipper/virtual_sdcard.py
FILE18_UPDATE=/home/pi/upgrade/others/10-video.rules
FILE19_UPDATE=/home/pi/upgrade/others/99-galcore-permissions.rules
FILE20_UPDATE=/home/pi/upgrade/others/factoryreset
FILE21_UPDATE=/home/pi/upgrade/others/webcam.txt
FILE22_UPDATE=/home/pi/upgrade/others/monitor
FILE23_UPDATE=/home/pi/upgrade/others/input_uvc.so

FILE24_UPDATE=/home/pi/upgrade/gcodes/*
FILE25_UPDATE=/home/pi/upgrade/klipper/display_status.py
FILE26_UPDATE=/home/pi/upgrade/klipper/save_variables.py
FILE27_UPDATE=/home/pi/upgrade/klipper/mcu.py
FILE28_UPDATE=/home/pi/upgrade/klipper/__init__.py
FILE29_UPDATE=/home/pi/upgrade/klipper/filament_switch_sensor.py
FILE30_UPDATE=/home/pi/upgrade/klipper/print_stats.py
FILE31_UPDATE=/home/pi/upgrade/klipper/bed_mesh.py
FILE32_UPDATE=/home/pi/upgrade/klipper/fan.py
FILE33_UPDATE=/home/pi/upgrade/others/dhclient.conf
FILE34_UPDATE=/home/pi/upgrade/klipper/gcode.py
FILE35_UPDATE=/home/pi/upgrade/klipper/queuelogger.py
FILE36_UPDATE=/home/pi/upgrade/others/fw_bcm43438a1.bin
FILE37_UPDATE=/home/pi/upgrade/others/config.txt
#FILE1_UPDATE_LOCATION_CONFIG=/home/pi/qt/out_linux/tuiconfig.ini
FILE38_UPDATE=/home/pi/upgrade/klipper/klippy.py

FILE39_UPDATE=/home/pi/upgrade/klipper/power_loss_recover.py
FILE40_UPDATE=/home/pi/upgrade/klipper/save_temp_variables.py
FILE41_UPDATE=/home/pi/upgrade/klipper/util.py

FILE42_UPDATE=/home/pi/upgrade/others/um
FILE43_UPDATE=/home/pi/upgrade/others/umb
FILE44_UPDATE=/home/pi/upgrade/klipper/resonance_tester.py
FILE45_UPDATE=/home/pi/upgrade/klipper/box_light.py
FILE46_UPDATE=/home/pi/upgrade/klipper/locate_printing_gcode.py
FILE47_UPDATE=/home/pi/upgrade/klipper/flsun_warning.py
FILE48_UPDATE=/home/pi/upgrade/klipper/rotate_logger.py
FILE49_UPDATE=/home/pi/upgrade/others/10-uname


FILE_UPDATE_LOCATION_MAINSAIL=/home/pi/mainsail
FILE1_UPDATE_LOCATION=/home/pi/qt/out_linux
FILE2_UPDATE_LOCATION=/etc/rc.local
FILE3_UPDATE_LOCATION=/home/pi/printer_data/config/printer.cfg
FILE4_UPDATE_LOCATION=/home/pi/flsun_func
FILE5_UPDATE_LOCATION=/home/pi/klipper/klippy/kinematics/delta.py
FILE6_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/filament_motion_sensor.py
FILE7_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/gcode_move.py
FILE8_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/heaters.py
FILE9_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/homing.py
FILE10_UPDATE_LOCATION=/etc/cfg
FILE11_UPDATE_LOCATION=/usr/local/bin/webcamd
FILE12_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/shaper_calibrate.py
FILE13_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/shaper_defs.py
FILE14_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/stepper_enable.py
FILE15_UPDATE_LOCATION=/home/pi/klipper/klippy/toolhead.py
FILE16_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/verify_heater.py
FILE17_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/virtual_sdcard.py
FILE18_UPDATE_LOCATION=/etc/udev/rules.d/10-video.rules
FILE19_UPDATE_LOCATION=/etc/udev/rules.d/99-galcore-permissions.rules
FILE20_UPDATE_LOCATION=/etc/factoryreset
FILE21_UPDATE_LOCATION=/home/pi/klipper_config/webcam.txt
FILE22_UPDATE_LOCATION=/etc/monitor
FILE23_UPDATE_LOCATION=/home/pi/mjpg-streamer/input_uvc.so

FILE24_UPDATE_LOCATION=/home/pi/printer_data/gcodes/
FILE25_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/display_status.py
FILE26_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/save_variables.py
FILE27_UPDATE_LOCATION=/home/pi/klipper/klippy/mcu.py
FILE28_UPDATE_LOCATION=/home/pi/klipper/klippy/chelper/__init__.py
FILE29_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/filament_switch_sensor.py
FILE30_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/print_stats.py
FILE31_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/bed_mesh.py
FILE32_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/fan.py
FILE33_UPDATE_LOCATION=/etc/dhcp/dhclient.conf
FILE34_UPDATE_LOCATION=/home/pi/klipper/klippy/gcode.py
FILE35_UPDATE_LOCATION=/home/pi/klipper/klippy/queuelogger.py
FILE36_UPDATE_LOCATION=/vendor/etc/firmware/fw_bcm43438a1.bin
FILE37_UPDATE_LOCATION=/vendor/etc/firmware/config.txt
FILE38_UPDATE_LOCATION=/home/pi/klipper/klippy/klippy.py

FILE39_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/power_loss_recover.py
FILE40_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/save_temp_variables.py

FILE41_UPDATE_LOCATION=/home/pi/klipper/klippy/util.py
FILE42_UPDATE_LOCATION=/etc/um
FILE43_UPDATE_LOCATION=/etc/umb

FILE44_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/resonance_tester.py
FILE45_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/box_light.py 
FILE46_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/locate_printing_gcode.py 
FILE47_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/flsun_warning.py
FILE48_UPDATE_LOCATION=/home/pi/klipper/klippy/extras/rotate_logger.py
FILE49_UPDATE_LOCATION=/etc/update-motd.d/10-uname

FILE1_BAK_BEFORE=/home/pi/qt/out_linux
FILE2_BAK_BEFORE=/etc/rc.local
FILE3_BAK_BEFORE=/home/pi/printer_data/config/printer.cfg
FILE4_BAK_BEFORE=/home/pi/flsun_func
FILE5_BAK_BEFORE=/home/pi/klipper/klippy/kinematics/delta.py
FILE6_BAK_BEFORE=/home/pi/klipper/klippy/extras/filament_motion_sensor.py
FILE7_BAK_BEFORE=/home/pi/klipper/klippy/extras/gcode_move.py
FILE8_BAK_BEFORE=/home/pi/klipper/klippy/extras/heaters.py
FILE9_BAK_BEFORE=/home/pi/klipper/klippy/extras/homing.py
FILE10_BAK_BEFORE=/etc/cfg
FILE11_BAK_BEFORE=/usr/local/bin/webcamd
FILE12_BAK_BEFORE=/home/pi/klipper/klippy/extras/shaper_calibrate.py
FILE13_BAK_BEFORE=/home/pi/klipper/klippy/extras/shaper_defs.py
FILE14_BAK_BEFORE=/home/pi/klipper/klippy/extras/stepper_enable.py
FILE15_BAK_BEFORE=/home/pi/klipper/klippy/toolhead.py
FILE16_BAK_BEFORE=/home/pi/klipper/klippy/extras/verify_heater.py
FILE17_BAK_BEFORE=/home/pi/klipper/klippy/extras/virtual_sdcard.py
FILE18_BAK_BEFORE=/etc/udev/rules.d/10-video.rules
FILE19_BAK_BEFORE=/etc/udev/rules.d/99-galcore-permissions.rules
FILE20_BAK_BEFORE=/etc/factoryreset
FILE21_BAK_BEFORE=/home/pi/klipper_config/webcam.txt
FILE22_BAK_BEFORE=/etc/monitor
FILE23_BAK_BEFORE=/home/pi/mjpg-streamer/input_uvc.so
FILE25_BAK_BEFORE=/home/pi/klipper/klippy/extras/display_status.py
FILE26_BAK_BEFORE=/home/pi/klipper/klippy/extras/save_variables.py
FILE27_BAK_BEFORE=/home/pi/klipper/klippy/mcu.py
FILE28_BAK_BEFORE=/home/pi/klipper/klippy/chelper/__init__.py
FILE29_BAK_BEFORE=/home/pi/klipper/klippy/extras/filament_switch_sensor.py
FILE30_BAK_BEFORE=/home/pi/klipper/klippy/extras/print_stats.py
FILE31_BAK_BEFORE=/home/pi/klipper/klippy/extras/bed_mesh.py
FILE32_BAK_BEFORE=/home/pi/klipper/klippy/extras/fan.py
FILE33_BAK_BEFORE=/etc/dhcp/dhclient.conf
FILE34_BAK_BEFORE=/home/pi/klipper/klippy/gcode.py
FILE35_BAK_BEFORE=/home/pi/klipper/klippy/queuelogger.py
FILE36_BAK_BEFORE=/vendor/etc/firmware/fw_bcm43438a1.bin
FILE37_BAK_BEFORE=/vendor/etc/firmware/config.txt
FILE38_BAK_BEFORE=/home/pi/klipper/klippy/klippy.py

FILE1_BAK=$UPDATE_BAK_CACHE_DIR/out_linux
FILE2_BAK=$UPDATE_BAK_CACHE_DIR/rc.local
FILE3_BAK=$UPDATE_BAK_CACHE_DIR/printer.cfg
FILE4_BAK=$UPDATE_BAK_CACHE_DIR/flsun_func
FILE5_BAK=$UPDATE_BAK_CACHE_DIR/delta.py
FILE6_BAK=$UPDATE_BAK_CACHE_DIR/filament_motion_sensor.py
FILE7_BAK=$UPDATE_BAK_CACHE_DIR/gcode_move.py
FILE8_BAK=$UPDATE_BAK_CACHE_DIR/heaters.py
FILE9_BAK=$UPDATE_BAK_CACHE_DIR/homing.py
FILE10_BAK=$UPDATE_BAK_CACHE_DIR/cfg
FILE11_BAK=$UPDATE_BAK_CACHE_DIR/webcamd
FILE12_BAK=$UPDATE_BAK_CACHE_DIR/shaper_calibrate.py
FILE13_BAK=$UPDATE_BAK_CACHE_DIR/shaper_defs.py
FILE14_BAK=$UPDATE_BAK_CACHE_DIR/stepper_enable.py
FILE15_BAK=$UPDATE_BAK_CACHE_DIR/toolhead.py
FILE16_BAK=$UPDATE_BAK_CACHE_DIR/verify_heater.py
FILE17_BAK=$UPDATE_BAK_CACHE_DIR/virtual_sdcard.py
FILE18_BAK=$UPDATE_BAK_CACHE_DIR/10-video.rules
FILE19_BAK=$UPDATE_BAK_CACHE_DIR/99-galcore-permissions.rules
FILE20_BAK=$UPDATE_BAK_CACHE_DIR/factoryreset
FILE21_BAK=$UPDATE_BAK_CACHE_DIR/webcam.txt
FILE22_BAK=$UPDATE_BAK_CACHE_DIR/monitor
FILE23_BAK=$UPDATE_BAK_CACHE_DIR/input_uvc.so
FILE25_BAK=$UPDATE_BAK_CACHE_DIR/display_status.py
FILE26_BAK=$UPDATE_BAK_CACHE_DIR/save_variables.py
FILE27_BAK=$UPDATE_BAK_CACHE_DIR/mcu.py
FILE28_BAK=$UPDATE_BAK_CACHE_DIR/__init__.py
FILE29_BAK=$UPDATE_BAK_CACHE_DIR/filament_switch_sensor.py
FILE30_BAK=$UPDATE_BAK_CACHE_DIR/print_stats.py
FILE31_BAK=$UPDATE_BAK_CACHE_DIR/bed_mesh.py
FILE32_BAK=$UPDATE_BAK_CACHE_DIR/fan.py
FILE33_BAK=$UPDATE_BAK_CACHE_DIR/dhclient.conf
FILE34_BAK=$UPDATE_BAK_CACHE_DIR/gcode.py
FILE35_BAK=$UPDATE_BAK_CACHE_DIR/queuelogger.py
FILE36_BAK=$UPDATE_BAK_CACHE_DIR/fw_bcm43438a1.bin
FILE37_BAK=$UPDATE_BAK_CACHE_DIR/config.txt
FILE38_BAK=$UPDATE_BAK_CACHE_DIR/klippy.py

#FILE_CONFIG_BAK=$UPDATE_BAK_CACHE_DIR/tuiconfig.ini

RECOVERY_SCRIPT=/home/pi/upgrade/recovery.sh

UPDATE_PROGRESS=/home/pi/upgrade/update_progress

if [ ! -f "$ONLINE_UPDATE_MESG" ]; then
	touch $ONLINE_UPDATE_MESG
else
	echo "" > $ONLINE_UPDATE_MESG
fi

if grep -q "FLSunS1Pro" "/etc/hostname" ;then
	echo "hostname is FLSunS1Pro" >> $ONLINE_UPDATE_MESG
	exit
fi

if grep -q "FLSunS1" "/etc/hostname" ;then
	echo "hostname is FLSunS1" >> $ONLINE_UPDATE_MESG
	exit
fi

if grep -q "FLSunT1E" "/etc/hostname" ;then
	echo "hostname is FLSunT1E" >> $ONLINE_UPDATE_MESG
	exit
fi

if grep -q "FLSunT1Pro" "/etc/hostname" ;then
	echo "hostname is FLSunT1Pro" >> $ONLINE_UPDATE_MESG
fi

if [ ! -f "$UPDATE_PROGRESS" ]; then
	touch $UPDATE_PROGRESS
else
	echo "0" > $UPDATE_PROGRESS
fi
echo "0" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG
sync

chmod +x /home/pi/upgrade/fan_max_power_handle.sh
/home/pi/upgrade/fan_max_power_handle.sh
cat /home/pi/mesg/fan_mesg >> $ONLINE_UPDATE_MESG

##调平、振动补偿数据不修改,把数据更新到升级文件中

update_cfg_file()
{
	update_file=$1
	local_file=$2
	flag=true
	
	if [ ! -f "$update_file" ] || [ ! -f "$local_file" ]; then
		return 1;
	fi
		
#使用 sed 命令删除包含 #*# 符号之后的所有行，并直接修改update_file
	sed -i '/\#\*\#/q' "$update_file"

#拷贝local_file文件#*# 符号之后的所有行到update_file
	while read a_line
	do
		if [ `echo ${a_line} | grep -w "\#\*\#" | wc -l` -ge 1 ]; then
			if [ $flag = true ];then
				flag=false
				continue
			fi
			echo "${a_line}" >> $update_file
		else
			continue
		fi

	done < $local_file

	return 0;
}
update_zboot()
{
	if [ -f "/home/pi/upgrade/others/flsun_kernel_write" ] && [ -f "/home/pi/upgrade/others/zboot.img" ];then
		cd /home/pi/upgrade/others/
		chmod +x /home/pi/upgrade/others/flsun_kernel_write
		/home/pi/upgrade/others/flsun_kernel_write
		cd -
		echo "update_zboot success"        >>    $ONLINE_UPDATE_MESG
	else
		echo "no zboot files "        >>    $ONLINE_UPDATE_MESG
	fi
	
	return 0;
}


free_space=$(df -BM / | awk 'NR==2 {print $4}' | tr -d 'M')
 echo "free_space=$free_space"        >>    $ONLINE_UPDATE_MESG
if [ $free_space -gt 500 ]; then
    echo "updating..."        >>    $ONLINE_UPDATE_MESG
else
    echo "Not enough space left"        >>    $ONLINE_UPDATE_MESG
	exit
fi
echo "update start"                                														>>  	$ONLINE_UPDATE_MESG
date                                               														>>  	$ONLINE_UPDATE_MESG 

echo "FLSunT1Pro" > /etc/hostname	       && echo "hostname change ok"      >>    $ONLINE_UPDATE_MESG

update_zboot
echo "update zboot success"                                												>>  	$ONLINE_UPDATE_MESG

echo "10" > $UPDATE_PROGRESS
echo "10" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG
sync

if [ -f "$UPDATE_SUCCESS_FLAG" ]; then
	rm -f $UPDATE_SUCCESS_FLAG        && echo "RM_UPDATE_SUCCESS_FLAG_OK"      >>    $ONLINE_UPDATE_MESG
else
	echo "UPDATE_SUCCESS_FLAG_NOT_EXIT"             >> $ONLINE_UPDATE_MESG
fi

if [ -f "$UPDATE_FAIL_FLAG" ]; then
	rm -f $UPDATE_FAIL_FLAG        && echo "RM_UPDATE_FAIL_FLAG_OK"      >>    $ONLINE_UPDATE_MESG
else
	echo "UPDATE_FAIL_FLAG_NOT_EXIT"                                     >> $ONLINE_UPDATE_MESG
fi

if [ -f "$FILE_UUPDATE" ]; then
	rm -rf $FILE_UUPDATE        && echo "RM_FILE_UUPDATE_OK"      >>    $ONLINE_UPDATE_MESG
else
	echo "FILE_UUPDATE_NOT_EXIT"             >> $ONLINE_UPDATE_MESG
fi

if [ ! -d $UPDATE_BAK_CACHE_DIR ]; then
  	mkdir $UPDATE_BAK_CACHE_DIR 		&& echo "UPDATE_BAK_CACHE_DIR_OK"      >>    $ONLINE_UPDATE_MESG 
else
	rm -rf $UPDATE_BAK_CACHE_DIR/*	&& echo "UPDATE_BAK_CACHE_DIR_OK"      >>    $ONLINE_UPDATE_MESG 
fi

if [ ! -d $UPDATE_BAK_DIR ]; then
  	mkdir $UPDATE_BAK_DIR 		&& echo "UPDATE_BAK_DIR_OK"      >>    $ONLINE_UPDATE_MESG
else
	echo "UPDATE_BAK_DIR exist"      >>    $ONLINE_UPDATE_MESG 
fi

if [ ! -d "$FILE1_UPDATE" ] || [ ! -f "$FILE2_UPDATE" ] || [  ! -f "$FILE3_UPDATE"  ] || [  ! -d "$FILE4_UPDATE"  ] || [  ! -f "$FILE5_UPDATE"  ] || [  ! -f "$FILE6_UPDATE"  ] || [  ! -f "$FILE7_UPDATE"  ]; then
	echo "file_update does not exist"     >>    $ONLINE_UPDATE_MESG 
	exit
else
	echo "file_update exist"     >>    $ONLINE_UPDATE_MESG
fi
if [ ! -f "$FILE8_UPDATE" ] || [ ! -f "$FILE9_UPDATE" ] || [  ! -f "$FILE10_UPDATE"  ] || [  ! -f "$FILE11_UPDATE"  ] || [  ! -f "$FILE12_UPDATE"  ] || [  ! -f "$FILE13_UPDATE"  ] || [  ! -f "$FILE14_UPDATE"  ]; then
	echo "file_update does not exist"     >>    $ONLINE_UPDATE_MESG 
	exit
else
	echo "file_update exist"     >>    $ONLINE_UPDATE_MESG
fi
if [ ! -f "$FILE15_UPDATE" ] || [ ! -f "$FILE16_UPDATE" ] || [  ! -f "$FILE17_UPDATE"  ] || [ ! -f "$FILE18_UPDATE" ] || [ ! -f "$FILE19_UPDATE" ] || [  ! -f "$FILE20_UPDATE"  ] || [  ! -f "$FILE21_UPDATE"  ] || [  ! -f "$FILE22_UPDATE"  ] || [  ! -f "$FILE23_UPDATE"  ] || [  ! -f "$FILE25_UPDATE"  ] || [  ! -f "$FILE26_UPDATE"  ] || [  ! -f "$FILE27_UPDATE"  ] || [  ! -f "$FILE28_UPDATE"  ] || [  ! -f "$FILE29_UPDATE"  ] || [  ! -f "$FILE30_UPDATE"  ] || [  ! -f "$FILE31_UPDATE"  ] || [ ! -f "$FILE32_UPDATE" ] || [ ! -f "$FILE33_UPDATE" ] || [ ! -f "$FILE34_UPDATE" ] || [ ! -f "$FILE35_UPDATE" ] || [ ! -f "$FILE36_UPDATE" ] || [ ! -f "$FILE37_UPDATE" ] || [ ! -f "$FILE38_UPDATE" ]; then
	echo "file_update does not exist"     >>    $ONLINE_UPDATE_MESG 
	exit
else
	echo "file_update exist"     >>    $ONLINE_UPDATE_MESG
fi

if [ ! -d "$FILE1_BAK_BEFORE" ] || [ ! -f "$FILE2_BAK_BEFORE" ] || [  ! -f "$FILE3_BAK_BEFORE"  ] || [ ! -d "$FILE4_BAK_BEFORE" ] || [  ! -f "$FILE5_BAK_BEFORE"  ] || [ ! -f "$FILE6_BAK_BEFORE" ] || [  ! -f "$FILE7_BAK_BEFORE"  ]; then
	echo "file_bak_before does not exist"        >>    $ONLINE_UPDATE_MESG 
	exit
else 
	echo "file_bak_before exist"        >>    $ONLINE_UPDATE_MESG
fi
if [ ! -f "$FILE8_BAK_BEFORE" ] || [ ! -f "$FILE9_BAK_BEFORE" ] || [  ! -f "$FILE10_BAK_BEFORE"  ] || [  ! -f "$FILE11_BAK_BEFORE"  ] || [  ! -f "$FILE12_BAK_BEFORE"  ] || [ ! -f "$FILE13_BAK_BEFORE" ] || [  ! -f "$FILE14_BAK_BEFORE"  ]; then
	echo "file_bak_before does not exist"        >>    $ONLINE_UPDATE_MESG 
	exit
else 
	echo "file_bak_before exist"        >>    $ONLINE_UPDATE_MESG
fi
if [ ! -f "$FILE15_BAK_BEFORE" ] || [ ! -f "$FILE16_BAK_BEFORE" ] || [  ! -f "$FILE17_BAK_BEFORE"  ] || [ ! -f "$FILE18_BAK_BEFORE" ] || [ ! -f "$FILE19_BAK_BEFORE" ] || [ ! -f "$FILE20_BAK_BEFORE" ] || [  ! -f "$FILE21_BAK_BEFORE"  ] || [ ! -f "$FILE22_BAK_BEFORE" ] || [ ! -f "$FILE23_BAK_BEFORE" ] || [ ! -f "$FILE25_BAK_BEFORE" ] || [ ! -f "$FILE26_BAK_BEFORE" ] || [ ! -f "$FILE27_BAK_BEFORE" ] || [ ! -f "$FILE28_BAK_BEFORE" ] || [ ! -f "$FILE29_BAK_BEFORE" ] || [ ! -f "$FILE30_BAK_BEFORE" ] || [ ! -f "$FILE31_BAK_BEFORE" ] || [ ! -f "$FILE32_BAK_BEFORE" ] || [ ! -f "$FILE33_BAK_BEFORE" ] || [ ! -f "$FILE34_BAK_BEFORE" ] || [ ! -f "$FILE35_BAK_BEFORE" ] || [ ! -f "$FILE36_BAK_BEFORE" ] || [ ! -f "$FILE38_BAK_BEFORE" ]; then
	echo "file_bak_before does not exist"        >>    $ONLINE_UPDATE_MESG 
	exit
else 
	echo "file_bak_before exist"        >>    $ONLINE_UPDATE_MESG
fi

rm -rf $UPDATE_BAK_TMP_DIR   && echo "UPDATE_BAK_TMP_DIR_DEL_OK"      >>    $ONLINE_UPDATE_MESG 


echo "20" > $UPDATE_PROGRESS
echo "20" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG
sync

BAK_DIR_CACHE_EMPTY=$(grep "UPDATE_BAK_CACHE_DIR" $ONLINE_UPDATE_MESG)
date                                               								>>    $ONLINE_UPDATE_MESG 
#if [ "$(ls -A $UPDATE_BAK_DIR)" ]; then
if [ $BAK_DIR_CACHE_EMPTY ]; then
	
	cp -raf $FILE1_BAK_BEFORE $FILE1_BAK     && echo "FILE1_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG 
	cp -raf $FILE2_BAK_BEFORE $FILE2_BAK     && echo "FILE2_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE3_BAK_BEFORE $FILE3_BAK     && echo "FILE3_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE4_BAK_BEFORE $FILE4_BAK     && echo "FILE4_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG 
	cp -raf $FILE5_BAK_BEFORE $FILE5_BAK     && echo "FILE5_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE6_BAK_BEFORE $FILE6_BAK     && echo "FILE6_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE7_BAK_BEFORE $FILE7_BAK     && echo "FILE7_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG 
	cp -raf $FILE8_BAK_BEFORE $FILE8_BAK     && echo "FILE8_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE9_BAK_BEFORE $FILE9_BAK     && echo "FILE9_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE10_BAK_BEFORE $FILE10_BAK     && echo "FILE10_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE11_BAK_BEFORE $FILE11_BAK     && echo "FILE11_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE12_BAK_BEFORE $FILE12_BAK     && echo "FILE12_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE13_BAK_BEFORE $FILE13_BAK     && echo "FILE13_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE14_BAK_BEFORE $FILE14_BAK     && echo "FILE14_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE15_BAK_BEFORE $FILE15_BAK     && echo "FILE15_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE16_BAK_BEFORE $FILE16_BAK     && echo "FILE16_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE17_BAK_BEFORE $FILE17_BAK     && echo "FILE17_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE18_BAK_BEFORE $FILE18_BAK     && echo "FILE18_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE19_BAK_BEFORE $FILE19_BAK     && echo "FILE19_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE20_BAK_BEFORE $FILE20_BAK     && echo "FILE20_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE21_BAK_BEFORE $FILE21_BAK     && echo "FILE21_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE22_BAK_BEFORE $FILE22_BAK     && echo "FILE22_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE23_BAK_BEFORE $FILE23_BAK     && echo "FILE23_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE25_BAK_BEFORE $FILE25_BAK     && echo "FILE25_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE26_BAK_BEFORE $FILE26_BAK     && echo "FILE26_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE27_BAK_BEFORE $FILE27_BAK     && echo "FILE27_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE28_BAK_BEFORE $FILE28_BAK     && echo "FILE28_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE29_BAK_BEFORE $FILE29_BAK     && echo "FILE29_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE30_BAK_BEFORE $FILE30_BAK     && echo "FILE30_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE31_BAK_BEFORE $FILE31_BAK     && echo "FILE31_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE32_BAK_BEFORE $FILE32_BAK     && echo "FILE32_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE33_BAK_BEFORE $FILE33_BAK     && echo "FILE33_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE34_BAK_BEFORE $FILE34_BAK     && echo "FILE34_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE35_BAK_BEFORE $FILE35_BAK     && echo "FILE35_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE36_BAK_BEFORE $FILE36_BAK     && echo "FILE36_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
	cp -raf $FILE38_BAK_BEFORE $FILE38_BAK     && echo "FILE38_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
else
	echo "update_bak_dir is not empty"     >>    $ONLINE_UPDATE_MESG 
	exit
fi

echo "30" > $UPDATE_PROGRESS
echo "30" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG
sync

BAK_RESULT_1=$(grep "FILE1_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_2=$(grep "FILE2_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_3=$(grep "FILE3_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_4=$(grep "FILE4_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_5=$(grep "FILE5_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_6=$(grep "FILE6_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_7=$(grep "FILE7_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_8=$(grep "FILE8_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_9=$(grep "FILE9_BAK_FINISH" 	$ONLINE_UPDATE_MESG)
BAK_RESULT_10=$(grep "FILE10_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_11=$(grep "FILE11_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_12=$(grep "FILE12_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_13=$(grep "FILE13_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_14=$(grep "FILE14_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_15=$(grep "FILE15_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_16=$(grep "FILE16_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_17=$(grep "FILE17_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_18=$(grep "FILE18_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_19=$(grep "FILE19_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_20=$(grep "FILE20_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_21=$(grep "FILE21_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_22=$(grep "FILE22_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_23=$(grep "FILE23_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_25=$(grep "FILE25_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_26=$(grep "FILE26_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_27=$(grep "FILE27_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_28=$(grep "FILE28_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_29=$(grep "FILE29_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_30=$(grep "FILE30_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_31=$(grep "FILE31_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_32=$(grep "FILE32_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_33=$(grep "FILE33_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_34=$(grep "FILE34_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_35=$(grep "FILE35_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_36=$(grep "FILE36_BAK_FINISH" $ONLINE_UPDATE_MESG)
BAK_RESULT_38=$(grep "FILE38_BAK_FINISH" $ONLINE_UPDATE_MESG)

if [ $BAK_RESULT_1 ] && [ $BAK_RESULT_2 ] && [ $BAK_RESULT_3 ]  && [ $BAK_RESULT_4 ] && [ $BAK_RESULT_5 ]  && [ $BAK_RESULT_6 ] && [ $BAK_RESULT_7 ]  && [ $BAK_RESULT_8 ] && [ $BAK_RESULT_9 ]  && [ $BAK_RESULT_10 ] && [ $BAK_RESULT_11 ] && [ $BAK_RESULT_12 ] && [ $BAK_RESULT_13 ]  && [ $BAK_RESULT_14 ] && [ $BAK_RESULT_15 ]  && [ $BAK_RESULT_16 ] && [ $BAK_RESULT_17 ] && [ $BAK_RESULT_18 ] && [ $BAK_RESULT_19 ]  && [ $BAK_RESULT_20 ] && [ $BAK_RESULT_21 ] && [ $BAK_RESULT_22 ] && [ $BAK_RESULT_23 ] && [ $BAK_RESULT_25 ] && [ $BAK_RESULT_26 ] && [ $BAK_RESULT_27 ] && [ $BAK_RESULT_28 ] && [ $BAK_RESULT_29 ] && [ $BAK_RESULT_30 ] && [ $BAK_RESULT_31 ] && [ $BAK_RESULT_32 ] && [ $BAK_RESULT_33 ] && [ $BAK_RESULT_34 ] && [ $BAK_RESULT_35 ] && [ $BAK_RESULT_36 ] && [ $BAK_RESULT_38 ]; then
	#rm -rf $FILE1_BAK_BEFORE 		&& 	
	echo "FILE1_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE2_BAK_BEFORE		&& echo "FILE2_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE3_BAK_BEFORE		&& echo "FILE3_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE4_BAK_BEFORE		&& echo "FILE4_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE5_BAK_BEFORE		&& echo "FILE5_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE6_BAK_BEFORE		&& echo "FILE6_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE7_BAK_BEFORE		&& echo "FILE7_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE8_BAK_BEFORE		&& echo "FILE8_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE9_BAK_BEFORE		&& echo "FILE9_BAK_BEFORE_DEL_OK"      	>>    $ONLINE_UPDATE_MESG
	rm -rf $FILE10_BAK_BEFORE		&& echo "FILE10_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE11_BAK_BEFORE 		&& echo "FILE11_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE12_BAK_BEFORE		&& echo "FILE12_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE13_BAK_BEFORE		&& echo "FILE13_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE14_BAK_BEFORE		&& echo "FILE14_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE15_BAK_BEFORE		&& echo "FILE15_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE16_BAK_BEFORE		&& echo "FILE16_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE17_BAK_BEFORE		&& echo "FILE17_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE18_BAK_BEFORE		&& echo "FILE18_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE19_BAK_BEFORE		&& echo "FILE19_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE20_BAK_BEFORE		&& echo "FILE20_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE21_BAK_BEFORE		&& echo "FILE21_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE22_BAK_BEFORE		&& echo "FILE22_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE23_BAK_BEFORE		&& echo "FILE23_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE25_BAK_BEFORE		&& echo "FILE25_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE26_BAK_BEFORE		&& echo "FILE26_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE27_BAK_BEFORE		&& echo "FILE27_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE28_BAK_BEFORE		&& echo "FILE28_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE29_BAK_BEFORE		&& echo "FILE29_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE30_BAK_BEFORE		&& echo "FILE30_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE31_BAK_BEFORE		&& echo "FILE31_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE32_BAK_BEFORE		&& echo "FILE32_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE33_BAK_BEFORE		&& echo "FILE33_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE34_BAK_BEFORE		&& echo "FILE34_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE35_BAK_BEFORE		&& echo "FILE35_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE36_BAK_BEFORE		&& echo "FILE36_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE37_BAK_BEFORE		&& echo "FILE37_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	rm -rf $FILE38_BAK_BEFORE		&& echo "FILE38_BAK_BEFORE_DEL_OK"      >>    $ONLINE_UPDATE_MESG
	echo "Successfully back up files"        >>    $ONLINE_UPDATE_MESG
else 
	echo "Failed to back up files"           >>    $ONLINE_UPDATE_MESG
	exit
fi

echo "40" > $UPDATE_PROGRESS
echo "40" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG
sync

DEL_BAK_RESULT_1=$(grep "FILE1_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_2=$(grep "FILE2_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_3=$(grep "FILE3_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_4=$(grep "FILE4_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_5=$(grep "FILE5_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_6=$(grep "FILE6_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_7=$(grep "FILE7_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_8=$(grep "FILE8_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_9=$(grep "FILE9_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_10=$(grep "FILE10_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_11=$(grep "FILE11_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_12=$(grep "FILE12_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_13=$(grep "FILE13_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_14=$(grep "FILE14_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_15=$(grep "FILE15_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_16=$(grep "FILE16_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_17=$(grep "FILE17_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_18=$(grep "FILE18_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_19=$(grep "FILE19_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_20=$(grep "FILE20_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_21=$(grep "FILE21_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_22=$(grep "FILE22_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_23=$(grep "FILE23_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_25=$(grep "FILE25_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_26=$(grep "FILE26_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_27=$(grep "FILE27_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_28=$(grep "FILE28_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_29=$(grep "FILE29_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_30=$(grep "FILE30_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_31=$(grep "FILE31_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_32=$(grep "FILE32_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_33=$(grep "FILE33_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_34=$(grep "FILE34_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_35=$(grep "FILE35_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_36=$(grep "FILE36_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_37=$(grep "FILE37_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)
DEL_BAK_RESULT_38=$(grep "FILE38_BAK_BEFORE_DEL_OK" $ONLINE_UPDATE_MESG)

date                                               												>>    $ONLINE_UPDATE_MESG 

if [ $DEL_BAK_RESULT_1 ] && [ $DEL_BAK_RESULT_2 ] && [ $DEL_BAK_RESULT_3 ] && [ $DEL_BAK_RESULT_4 ] && [ $DEL_BAK_RESULT_5 ]  && [ $DEL_BAK_RESULT_6 ] && [ $DEL_BAK_RESULT_7 ]  && [ $DEL_BAK_RESULT_8 ] && [ $DEL_BAK_RESULT_9 ] && [ $DEL_BAK_RESULT_10 ] && [ $DEL_BAK_RESULT_11 ] && [ $DEL_BAK_RESULT_12 ] && [ $DEL_BAK_RESULT_13 ] && [ $DEL_BAK_RESULT_14 ] && [ $DEL_BAK_RESULT_15 ]  && [ $DEL_BAK_RESULT_16 ] && [ $DEL_BAK_RESULT_17 ] && [ $DEL_BAK_RESULT_18 ] && [ $DEL_BAK_RESULT_19 ]  && [ $DEL_BAK_RESULT_20 ] && [ $DEL_BAK_RESULT_21 ] && [ $DEL_BAK_RESULT_22 ] && [ $DEL_BAK_RESULT_23 ] && [ $DEL_BAK_RESULT_25 ] && [ $DEL_BAK_RESULT_26 ] && [ $DEL_BAK_RESULT_27 ] && [ $DEL_BAK_RESULT_28 ] && [ $DEL_BAK_RESULT_29 ] && [ $DEL_BAK_RESULT_30 ] && [ $DEL_BAK_RESULT_31 ] && [ $DEL_BAK_RESULT_32 ] && [ $DEL_BAK_RESULT_33 ] && [ $DEL_BAK_RESULT_34 ] && [ $DEL_BAK_RESULT_35 ] && [ $DEL_BAK_RESULT_36 ] && [ $DEL_BAK_RESULT_37 ] && [ $DEL_BAK_RESULT_38 ]; then
	if [ -d "$FILE1_UPDATE_DIR_LIB" ];then
		rm -rf $FILE1_UPDATE_DIR_LIB 		&& 	echo "FFILE1_UPDATE_DIR_LIB_DEL_OK"      		 >>    $ONLINE_UPDATE_MESG
	fi
	cp -raf $FILE1_UPDATE/*  $FILE1_UPDATE_LOCATION        	&& echo "FILE1_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE2_UPDATE  $FILE2_UPDATE_LOCATION        	&& echo "FILE2_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG	
	#调平、振动补偿数据不修改
	update_cfg_file $FILE3_UPDATE  $FILE3_BAK				
	echo "update_cfg_file"        	 															 >> $ONLINE_UPDATE_MESG
	cp -raf $FILE3_UPDATE  $FILE3_UPDATE_LOCATION        	&& echo "FILE3_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE4_UPDATE  $FILE4_UPDATE_LOCATION        	&& echo "FILE4_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE5_UPDATE  $FILE5_UPDATE_LOCATION        	&& echo "FILE5_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG	
	cp -raf $FILE6_UPDATE  $FILE6_UPDATE_LOCATION        	&& echo "FILE6_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE7_UPDATE  $FILE7_UPDATE_LOCATION        	&& echo "FILE7_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE8_UPDATE  $FILE8_UPDATE_LOCATION        	&& echo "FILE8_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE9_UPDATE  $FILE9_UPDATE_LOCATION        	&& echo "FILE9_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG	
	cp -raf $FILE10_UPDATE  $FILE10_UPDATE_LOCATION        && echo "FILE10_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE11_UPDATE  $FILE11_UPDATE_LOCATION        && echo "FILE11_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE12_UPDATE  $FILE12_UPDATE_LOCATION        && echo "FILE12_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG	
	cp -raf $FILE13_UPDATE  $FILE13_UPDATE_LOCATION        && echo "FILE13_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE14_UPDATE  $FILE14_UPDATE_LOCATION        && echo "FILE14_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE15_UPDATE  $FILE15_UPDATE_LOCATION        && echo "FILE15_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG	
	cp -raf $FILE16_UPDATE  $FILE16_UPDATE_LOCATION        && echo "FILE16_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE17_UPDATE  $FILE17_UPDATE_LOCATION        && echo "FILE17_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE18_UPDATE  $FILE18_UPDATE_LOCATION        && echo "FILE18_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE19_UPDATE  $FILE19_UPDATE_LOCATION        && echo "FILE19_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG	
	cp -raf $FILE20_UPDATE  $FILE20_UPDATE_LOCATION        && echo "FILE20_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE21_UPDATE  $FILE21_UPDATE_LOCATION        && echo "FILE21_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE22_UPDATE  $FILE22_UPDATE_LOCATION        && echo "FILE22_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE23_UPDATE  $FILE23_UPDATE_LOCATION        && echo "FILE23_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE24_UPDATE  $FILE24_UPDATE_LOCATION        && echo "FILE24_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE25_UPDATE  $FILE25_UPDATE_LOCATION        && echo "FILE25_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE26_UPDATE  $FILE26_UPDATE_LOCATION        && echo "FILE26_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE27_UPDATE  $FILE27_UPDATE_LOCATION        && echo "FILE27_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE28_UPDATE  $FILE28_UPDATE_LOCATION        && echo "FILE28_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE29_UPDATE  $FILE29_UPDATE_LOCATION        && echo "FILE29_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE30_UPDATE  $FILE30_UPDATE_LOCATION        && echo "FILE30_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE31_UPDATE  $FILE31_UPDATE_LOCATION        && echo "FILE31_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE32_UPDATE  $FILE32_UPDATE_LOCATION        && echo "FILE32_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE33_UPDATE  $FILE33_UPDATE_LOCATION        && echo "FILE33_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE34_UPDATE  $FILE34_UPDATE_LOCATION        && echo "FILE34_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE35_UPDATE  $FILE35_UPDATE_LOCATION        && echo "FILE35_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE36_UPDATE  $FILE36_UPDATE_LOCATION        && echo "FILE36_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE37_UPDATE  $FILE37_UPDATE_LOCATION        && echo "FILE37_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE38_UPDATE  $FILE38_UPDATE_LOCATION        && echo "FILE38_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	
	cp -raf $FILE39_UPDATE  $FILE39_UPDATE_LOCATION        && echo "FILE39_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE40_UPDATE  $FILE40_UPDATE_LOCATION        && echo "FILE40_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE41_UPDATE  $FILE41_UPDATE_LOCATION        && echo "FILE41_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE42_UPDATE  $FILE42_UPDATE_LOCATION        && echo "FILE42_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE43_UPDATE  $FILE43_UPDATE_LOCATION        && echo "FILE43_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE44_UPDATE  $FILE44_UPDATE_LOCATION        && echo "FILE44_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE45_UPDATE  $FILE45_UPDATE_LOCATION        && echo "FILE45_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE46_UPDATE  $FILE46_UPDATE_LOCATION        && echo "FILE46_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE47_UPDATE  $FILE47_UPDATE_LOCATION        && echo "FILE47_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE48_UPDATE  $FILE48_UPDATE_LOCATION        && echo "FILE48_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG
	cp -raf $FILE49_UPDATE  $FILE49_UPDATE_LOCATION        && echo "FILE49_UPDATE_FINISH"        >> $ONLINE_UPDATE_MESG

	echo "50" > $UPDATE_PROGRESS
	echo "50" >> $ONLINE_UPDATE_MESG
	date >> $ONLINE_UPDATE_MESG
	sync
	
	chown -R pi:pi		$FILE1_UPDATE_LOCATION				 	&& echo "CHOWN_FILE1_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE2_UPDATE_LOCATION				 	&& echo "CHOWN_FILE2_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R pi:pi		$FILE3_UPDATE_LOCATION				 	&& echo "CHOWN_FILE3_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE10_UPDATE_LOCATION					&& echo "CHOWN_FILE10_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE11_UPDATE_LOCATION					&& echo "CHOWN_FILE11_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE18_UPDATE_LOCATION					&& echo "CHOWN_FILE18_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE19_UPDATE_LOCATION					&& echo "CHOWN_FILE19_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE20_UPDATE_LOCATION					&& echo "CHOWN_FILE20_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE22_UPDATE_LOCATION					&& echo "CHOWN_FILE22_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE42_UPDATE_LOCATION					&& echo "CHOWN_FILE42_FINISH"        >> $ONLINE_UPDATE_MESG
	chown -R root:root	$FILE43_UPDATE_LOCATION					&& echo "CHOWN_FILE43_FINISH"        >> $ONLINE_UPDATE_MESG
	
	chown -R pi:pi /home/pi/klipper							&& echo "CHOWN_KLIPPER_FINISH"      >> $ONLINE_UPDATE_MESG
	chown -R pi:pi /home/pi/flsun_func						&& echo "CHOWN_FLSUN_FUNC_FINISH"   >> $ONLINE_UPDATE_MESG
	chown -R pi:pi /home/pi/printer_data/config				&& echo "CHOWN_PRINTER_DATA_FINISH" >> $ONLINE_UPDATE_MESG
	chown -R pi:pi /home/pi/printer_data/config_bak			&& echo "CHOWN_config_bak_FINISH" >> $ONLINE_UPDATE_MESG



	chmod 777 -R $FILE1_UPDATE_LOCATION						&& echo "CHMOD_FILE1_FINISH"      	 	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE2_UPDATE_LOCATION						&& echo "CHMOD_FILE2_FINISH"      	 	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE3_UPDATE_LOCATION						&& echo "CHMOD_FILE3_FINISH"      	 	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE10_UPDATE_LOCATION						&& echo "CHMOD_FILE10_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE11_UPDATE_LOCATION						&& echo "CHMOD_FILE11_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE18_UPDATE_LOCATION						&& echo "CHMOD_FILE18_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE19_UPDATE_LOCATION						&& echo "CHMOD_FILE19_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE20_UPDATE_LOCATION						&& echo "CHMOD_FILE20_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE22_UPDATE_LOCATION						&& echo "CHMOD_FILE22_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE42_UPDATE_LOCATION						&& echo "CHMOD_FILE42_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 $FILE43_UPDATE_LOCATION						&& echo "CHMOD_FILE43_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 755 $FILE49_UPDATE_LOCATION						&& echo "CHMOD_FILE49_FINISH"       	>> $ONLINE_UPDATE_MESG
  
	chmod 777 -R /home/pi/klipper							&& echo "CHMOD_KLIPPER_FINISH"       	>> $ONLINE_UPDATE_MESG
	chmod 777 -R /home/pi/flsun_func						&& echo "CHMOD_FLSUN_FUNC_FINISH"      	>> $ONLINE_UPDATE_MESG
	chmod 777 -R /home/pi/printer_data/config				&& echo "CHMOD_PRINTER_DATA_FINISH"     >> $ONLINE_UPDATE_MESG
	chmod 777 -R /home/pi/printer_data/config_bak			&& echo "CHMOD_config_bak_FINISH"       >> $ONLINE_UPDATE_MESG
else
	echo "Failed to delete the file_bak_before"     >>    $ONLINE_UPDATE_MESG
	exit
fi
date                                               								>>    $ONLINE_UPDATE_MESG 

echo "60" > $UPDATE_PROGRESS
echo "60" >> $ONLINE_UPDATE_MESG
date                                               								>>    $ONLINE_UPDATE_MESG 
sync

UPDATE_RESULT_1=$(grep "FILE1_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_2=$(grep "FILE2_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_3=$(grep "FILE3_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_4=$(grep "FILE4_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_5=$(grep "FILE5_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_6=$(grep "FILE6_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_7=$(grep "FILE7_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_8=$(grep "FILE8_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_9=$(grep "FILE9_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_10=$(grep "FILE10_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_11=$(grep "FILE11_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_12=$(grep "FILE12_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_13=$(grep "FILE13_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_14=$(grep "FILE14_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_15=$(grep "FILE15_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_16=$(grep "FILE16_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_17=$(grep "FILE17_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_18=$(grep "FILE18_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_19=$(grep "FILE19_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_20=$(grep "FILE20_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_21=$(grep "FILE21_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_22=$(grep "FILE22_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_23=$(grep "FILE23_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_24=$(grep "FILE24_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_25=$(grep "FILE25_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_26=$(grep "FILE26_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_27=$(grep "FILE27_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_28=$(grep "FILE28_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_29=$(grep "FILE29_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_30=$(grep "FILE30_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_31=$(grep "FILE31_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_32=$(grep "FILE32_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_33=$(grep "FILE33_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_34=$(grep "FILE34_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_35=$(grep "FILE35_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_36=$(grep "FILE36_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_37=$(grep "FILE37_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_38=$(grep "FILE38_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_39=$(grep "FILE39_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_40=$(grep "FILE40_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_41=$(grep "FILE41_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_42=$(grep "FILE42_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_43=$(grep "FILE43_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_44=$(grep "FILE44_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_45=$(grep "FILE45_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_46=$(grep "FILE46_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_47=$(grep "FILE47_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_48=$(grep "FILE48_UPDATE_FINISH" $ONLINE_UPDATE_MESG)
UPDATE_RESULT_49=$(grep "FILE49_UPDATE_FINISH" $ONLINE_UPDATE_MESG)

CHOWN_RESULT_1=$(grep "CHOWN_FILE1_FINISH" 			$ONLINE_UPDATE_MESG)
CHOWN_RESULT_2=$(grep "CHOWN_FILE2_FINISH" 			$ONLINE_UPDATE_MESG)
CHOWN_RESULT_3=$(grep "CHOWN_FILE3_FINISH" 			$ONLINE_UPDATE_MESG)
CHOWN_RESULT_10=$(grep "CHOWN_FILE10_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_11=$(grep "CHOWN_FILE10_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_18=$(grep "CHOWN_FILE18_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_19=$(grep "CHOWN_FILE19_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_20=$(grep "CHOWN_FILE20_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_22=$(grep "CHOWN_FILE22_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_42=$(grep "CHOWN_FILE42_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_43=$(grep "CHOWN_FILE43_FINISH" 		$ONLINE_UPDATE_MESG)

CHOWN_RESULT_A=$(grep "CHOWN_KLIPPER_FINISH" 		$ONLINE_UPDATE_MESG)
CHOWN_RESULT_B=$(grep "CHOWN_FLSUN_FUNC_FINISH" 	$ONLINE_UPDATE_MESG)
CHOWN_RESULT_C=$(grep "CHOWN_PRINTER_DATA_FINISH" 	$ONLINE_UPDATE_MESG)

CHMOD_RESULT_1=$(grep "CHMOD_FILE1_FINISH" 			$ONLINE_UPDATE_MESG)
CHMOD_RESULT_2=$(grep "CHMOD_FILE2_FINISH" 			$ONLINE_UPDATE_MESG)
CHMOD_RESULT_3=$(grep "CHMOD_FILE3_FINISH" 			$ONLINE_UPDATE_MESG)
CHMOD_RESULT_10=$(grep "CHMOD_FILE10_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_11=$(grep "CHMOD_FILE10_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_18=$(grep "CHMOD_FILE18_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_19=$(grep "CHMOD_FILE19_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_20=$(grep "CHMOD_FILE20_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_22=$(grep "CHMOD_FILE22_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_42=$(grep "CHMOD_FILE42_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_43=$(grep "CHMOD_FILE43_FINISH" 		$ONLINE_UPDATE_MESG)

CHMOD_RESULT_A=$(grep "CHMOD_KLIPPER_FINISH" 		$ONLINE_UPDATE_MESG)
CHMOD_RESULT_B=$(grep "CHMOD_FLSUN_FUNC_FINISH" 	$ONLINE_UPDATE_MESG)
CHMOD_RESULT_C=$(grep "CHMOD_PRINTER_DATA_FINISH" 	$ONLINE_UPDATE_MESG)

if [ $UPDATE_RESULT_1 ] && [ $UPDATE_RESULT_2 ] && [ $UPDATE_RESULT_3 ]  && [ $UPDATE_RESULT_4 ] && [ $UPDATE_RESULT_5 ] && [ $UPDATE_RESULT_6 ] && [ $UPDATE_RESULT_7 ] && [ $UPDATE_RESULT_8 ] && [ $UPDATE_RESULT_9 ] && [ $UPDATE_RESULT_10 ]&& [ $UPDATE_RESULT_11 ] && [ $UPDATE_RESULT_12 ] && [ $UPDATE_RESULT_13 ] && [ $UPDATE_RESULT_14 ] && [ $UPDATE_RESULT_15 ] && [ $UPDATE_RESULT_16 ] && [ $UPDATE_RESULT_17 ] && [ $UPDATE_RESULT_18 ] && [ $UPDATE_RESULT_19 ] && [ $UPDATE_RESULT_20 ] && [ $UPDATE_RESULT_21 ] && [ $UPDATE_RESULT_22 ] && [ $UPDATE_RESULT_23 ] && [ $UPDATE_RESULT_24 ] && [ $UPDATE_RESULT_25 ] && [ $UPDATE_RESULT_26 ] && [ $UPDATE_RESULT_27 ] && [ $UPDATE_RESULT_28 ] && [ $UPDATE_RESULT_29 ] && [ $UPDATE_RESULT_30 ] && [ $UPDATE_RESULT_31 ] && [ $UPDATE_RESULT_32 ] && [ $UPDATE_RESULT_33 ] && [ $UPDATE_RESULT_34 ] && [ $UPDATE_RESULT_35 ] && [ $UPDATE_RESULT_36 ] && [ $UPDATE_RESULT_37 ] && [ $UPDATE_RESULT_38 ] && [ $UPDATE_RESULT_39 ] && [ $UPDATE_RESULT_40 ] && [ $UPDATE_RESULT_41 ] && [ $UPDATE_RESULT_42 ] && [ $UPDATE_RESULT_43 ] && [ $UPDATE_RESULT_44 ] && [ $UPDATE_RESULT_45 ] && [ $UPDATE_RESULT_46 ] && [ $UPDATE_RESULT_47 ] && [ $UPDATE_RESULT_48 ]; then
	echo "ALL_FILE_UPDATE_FINISH_OK"      	                                                            >>    $ONLINE_UPDATE_MESG 
else
	echo "ALL_FILE_UPDATE_FINISH_NG"      	                                                            >>    $ONLINE_UPDATE_MESG
fi

if [ $CHOWN_RESULT_1 ] && [ $CHOWN_RESULT_2 ] && [ $CHOWN_RESULT_3 ] && [ $CHOWN_RESULT_10 ] && [ $CHOWN_RESULT_11 ] && [ $CHOWN_RESULT_18 ] && [ $CHOWN_RESULT_19 ] && [ $CHOWN_RESULT_20 ] && [ $CHOWN_RESULT_22 ] && [ $CHOWN_RESULT_42 ] && [ $CHOWN_RESULT_43 ] && [ $CHOWN_RESULT_A ] && [ $CHOWN_RESULT_B ] && [ $CHOWN_RESULT_C ]; then
	echo "ALL_FILE_CHOWN_FINISH_OK"      	                                                            >>    $ONLINE_UPDATE_MESG 
else
	echo "ALL_FILE_CHOWN_FINISH_NG"      	                                                            >>    $ONLINE_UPDATE_MESG
fi

if [ $CHMOD_RESULT_1 ] && [ $CHMOD_RESULT_2 ] && [ $CHMOD_RESULT_3 ] && [ $CHMOD_RESULT_10 ] && [ $CHMOD_RESULT_11 ] && [ $CHMOD_RESULT_18 ] && [ $CHMOD_RESULT_19 ] && [ $CHMOD_RESULT_20 ] && [ $CHMOD_RESULT_22 ]  && [ $CHMOD_RESULT_42 ] && [ $CHMOD_RESULT_43 ] && [ $CHMOD_RESULT_A ] && [ $CHMOD_RESULT_B ] && [ $CHMOD_RESULT_C ]; then
	echo "ALL_FILE_CHMOD_FINISH_OK"      	                                                            >>    $ONLINE_UPDATE_MESG 
else
	echo "ALL_FILE_CHMOD_FINISH_NG"      	                                                            >>    $ONLINE_UPDATE_MESG
fi

RESULT_FILE_UPDATE_ALL=$(grep   "ALL_FILE_UPDATE_FINISH_OK"     $ONLINE_UPDATE_MESG)
RESULT_FILE_CHOWN_ALL=$(grep   "ALL_FILE_CHOWN_FINISH_OK"       $ONLINE_UPDATE_MESG)
RESULT_FILE_CHMOD_ALL=$(grep   "ALL_FILE_CHMOD_FINISH_OK"       $ONLINE_UPDATE_MESG)
date                                               								>>    $ONLINE_UPDATE_MESG 
echo "70" > $UPDATE_PROGRESS
echo "70" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG
sync

#self
sync
#1
if [ -d "/home/pi/reset_bak/klipper" ]; then
	echo "/home/pi/reset_bak/klipper_exist"  																										>>    $ONLINE_UPDATE_MESG 
	rm -rf /home/pi/reset_bak/klipper												&& echo "reset_bak_klipper_DEL_OK"     	                  		>>    $ONLINE_UPDATE_MESG
else
	echo "/home/pi/reset_bak/klipper_not_exist"  																									>>    $ONLINE_UPDATE_MESG 
fi
#RESET_BAK_DEL_RESULT_1=$(grep "reset_bak_klipper_DEL_OK"  $ONLINE_UPDATE_MESG)
#if [ $RESET_BAK_DEL_RESULT_1 ]; then
  cp -radpf /home/pi/klipper /home/pi/reset_bak/				      				&& echo "CP_reset_bak_klipper_OK"      	              			>>    $ONLINE_UPDATE_MESG 
#else
#	echo "CP_reset_bak_klipper_NG"        									                                              				 			>>    $ONLINE_UPDATE_MESG
#fi

#2
if [ -d "/home/pi/reset_bak/flsun_func" ]; then
	echo "/home/pi/reset_bak/flsun_func_exist"  																					>>    $ONLINE_UPDATE_MESG 
	rm -rf /home/pi/reset_bak/flsun_func			&& echo "reset_bak_flsun_func_DEL_OK"     	                  		>>    $ONLINE_UPDATE_MESG
else
	echo "/home/pi/reset_bak/flsun_func/Structured_light_not_exist"  																				>>    $ONLINE_UPDATE_MESG 
fi
RESET_BAK_DEL_RESULT_2=$(grep "reset_bak_flsun_func_DEL_OK"  $ONLINE_UPDATE_MESG)
if [ $RESET_BAK_DEL_RESULT_2 ]; then
  cp -radpf /home/pi/flsun_func /home/pi/reset_bak/	 && echo "CP_reset_bak_flsun_func_OK"      	           >>    $ONLINE_UPDATE_MESG 
else
	echo "CP_reset_bak_flsun_func_NG"        									                                              					>>    $ONLINE_UPDATE_MESG
fi

#3 bak..........gocdes
#rm -rf /home/pi/reset_bak/printer_data/gcodes						&& echo "reset_bak_gcodes_DEL_OK"     	                  						>>    $ONLINE_UPDATE_MESG
#RESET_BAK_DEL_RESULT_3=$(grep "reset_bak_gcodes_DEL_OK"  $ONLINE_UPDATE_MESG)
#if [ $RESET_BAK_DEL_RESULT_3 ]; then
cp -radpf /home/pi/upgrade/gcodes/* /home/pi/reset_bak/printer_data/gcodes/	 && echo "CP_reset_bak_gcodes_OK"      	           					>>    $ONLINE_UPDATE_MESG 
#if [ -f "$FILE_RESETBAK_GCODE_DIR/slicener.gcode" ];then
#	rm	$FILE_RESETBAK_GCODE_DIR/slicener.gcode && echo "RM_resetbak_Silencer_gcodes_OK"      	           	>>    $ONLINE_UPDATE_MESG 
#  fi
#  if [ -f "$FILE_RESETBAK_GCODE_DIR/Fan Silencer.gcode" ];then
#	rm	"$FILE_RESETBAK_GCODE_DIR/Fan Silencer.gcode" && echo "RM_resetbak_Fan_Silencer_gcodes_OK"       	           			>>    $ONLINE_UPDATE_MESG 
#  fi
  
#else
#	echo "CP_reset_bak_gcodes_NG"        									                                              							>>    $ONLINE_UPDATE_MESG
#fi

#4
#rm -rf /home/pi/reset_bak/printer_data/config/flsun_func.cfg				&& echo "reset_bak_flsun_func_config_DEL_OK"     	                  		>>    $ONLINE_UPDATE_MESG
#RESET_BAK_DEL_RESULT_4=$(grep "reset_bak_config_DEL_OK"  $ONLINE_UPDATE_MESG)
if [ -d "/home/pi/reset_bak/printer_data/config" ]; then
  cp -radpf /home/pi/upgrade/config/* /home/pi/reset_bak/printer_data/config	 && echo "CP_reset_bak_config_OK"      	           						>>    $ONLINE_UPDATE_MESG 
else
	echo "CP_reset_bak_gcodes_NG"        									                                              							>>    $ONLINE_UPDATE_MESG
fi

#5
rm -rf /home/pi/reset_bak/klipper_config					&& echo "reset_bak_klipper_config_DEL_OK"     	                  						>>    $ONLINE_UPDATE_MESG
#RESET_BAK_DEL_RESULT_5=$(grep "reset_bak_klipper_config_DEL_OK"  $ONLINE_UPDATE_MESG)
#if [ $RESET_BAK_DEL_RESULT_5 ]; then
  cp -radpf /home/pi/klipper_config /home/pi/reset_bak/	 && echo "CP_reset_bak_klipper_config_OK"      	           									>>    $ONLINE_UPDATE_MESG 
#else
#	echo "CP_reset_bak_klipper_config_NG"        									                                              					>>    $ONLINE_UPDATE_MESG
#fi

#6
rm -rf /home/pi/reset_bak/qt/out_linux/TUI					&& echo "reset_bak_TUI_DEL_OK"     	                  				>>    $ONLINE_UPDATE_MESG
RESET_BAK_DEL_RESULT_6=$(grep "reset_bak_TUI_DEL_OK"  $ONLINE_UPDATE_MESG)
if [ $RESET_BAK_DEL_RESULT_6 ]; then
  cp -radpf /home/pi/qt/out_linux/TUI	/home/pi/reset_bak/qt/out_linux/TUI	 && echo "CP_reset_bak_TUI_OK"      	           						>>    $ONLINE_UPDATE_MESG 
else
	echo "CP_reset_bak_TUI_NG"        									                                              						>>    $ONLINE_UPDATE_MESG
fi

if [ -d "/home/pi/reset_bak/qt/out_linux/Config" ]; then
  cp -radpf /home/pi/upgrade/qt/out_linux/Config/IotCfg.json /home/pi/reset_bak/qt/out_linux/Config/IotCfg.json	 && echo "CP_QT_IOT_CONFIG_OK"      	           						>>    $ONLINE_UPDATE_MESG 
else
	mkdir /home/pi/reset_bak/qt/out_linux/Config				&& echo "/home/pi/reset_bak/qt/out_linux/Config ok"      	           						>>    $ONLINE_UPDATE_MESG
	cp -radpf /home/pi/upgrade/qt/out_linux/Config/IotCfg.json /home/pi/reset_bak/qt/out_linux/Config/IotCfg.json	 && echo "CP_QT_IOT_CONFIG_OK"      	           						>>    $ONLINE_UPDATE_MESG       									                                              							>>    $ONLINE_UPDATE_MESG
fi

cp -rf /home/pi/qt/out_linux/syssetting.ini /home/pi/reset_bak/qt/out_linux/syssetting.ini && echo "CP_QT_RESET_BAK_SYSCONFIG_OK"      	           						>>    $ONLINE_UPDATE_MESG 

cp -radpf $FILE23_UPDATE  /home/pi/reset_bak/mjpg-streamer/ 	&& echo "CP_mjpg-streamer_OK"      	           								>>    $ONLINE_UPDATE_MESG
#7
#rm -rf /home/pi/reset_bak/qt/out_linux/tuiconfig.ini				&& echo "reset_bak_tuiconfig_DEL_OK"     	                  				>>    $ONLINE_UPDATE_MESG
#RESET_BAK_DEL_RESULT_7=$(grep "reset_bak_tuiconfig_DEL_OK"  $ONLINE_UPDATE_MESG)
#if [ $RESET_BAK_DEL_RESULT_7 ]; then
#  cp -radpf $FILE1_UPDATE_CONFIG	/home/pi/reset_bak/qt/out_linux/tuiconfig.ini && echo "CP_reset_bak_tuiconfig_OK"      	           >>    $ONLINE_UPDATE_MESG 
  sed -i '2c guide=1' /home/pi/reset_bak/qt/out_linux/tuiconfig.ini  && echo "guide=1_OK"      	           									>>    $ONLINE_UPDATE_MESG
  #sed -i '7c language=english' /home/pi/reset_bak/qt/out_linux/tuiconfig.ini  && echo "language=english"      	           						>>    $ONLINE_UPDATE_MESG
  sed -i 's/language=chinese/language=english/' /home/pi/reset_bak/qt/out_linux/tuiconfig.ini && echo "language=english"				>>    $ONLINE_UPDATE_MESG
  sed -i 's/sleep=-1/sleep=10/' /home/pi/reset_bak/qt/out_linux/tuiconfig.ini && echo "sleep=10"										>>    $ONLINE_UPDATE_MESG
#else
#	echo "CP_reset_bak_tuiconfig_NG"        									                                              						>>    $ONLINE_UPDATE_MESG
#fi

#8
if [ -d "/home/pi/mainsail" ]; then
  cp -radpf /home/pi/upgrade/mainsail/* /home/pi/mainsail/	 && echo "CP_mainsail_OK"      	           						>>    $ONLINE_UPDATE_MESG 
else
	mkdir /home/pi/mainsail						&& echo "mkdir /home/pi/mainsail ok"      	           						>>    $ONLINE_UPDATE_MESG
	cp -radpf /home/pi/upgrade/mainsail/* /home/pi/mainsail/	 && echo "CP_mainsail_OK"      	           						>>    $ONLINE_UPDATE_MESG 
	#echo "CP_mainsail_NG"        									                                              							>>    $ONLINE_UPDATE_MESG
fi

#9
if [ -d "/home/pi/reset_bak/mainsail" ]; then
  cp -radpf /home/pi/upgrade/mainsail/* /home/pi/reset_bak/mainsail/	 && echo "CP_reset_bak_mainsail_OK"      	           						>>    $ONLINE_UPDATE_MESG 
else
	mkdir /home/pi/reset_bak/mainsail						&& echo "mkdir /home/pi/reset_bak/mainsail ok"      	           						>>    $ONLINE_UPDATE_MESG
	cp -radpf /home/pi/upgrade/mainsail/* /home/pi/reset_bak/mainsail/	 && echo "CP_reset_bak_mainsail_OK"      	           						>>    $ONLINE_UPDATE_MESG 
	#echo "CP_reset_bak_mainsail_NG"        									                                              							>>    $ONLINE_UPDATE_MESG
fi

cp -raf /home/pi/upgrade/others/logrotate.conf /etc/logrotate.conf && echo "cp logrotate.conf ok"		>> $ONLINE_UPDATE_MESG
cp -raf /home/pi/upgrade/others/logrotate.d/* /etc/logrotate.d/ && echo "cp logrotate.d ok"		>> $ONLINE_UPDATE_MESG
cp -raf /home/pi/upgrade/others/check_log /etc/check_log && echo "cp check_log ok"		>> $ONLINE_UPDATE_MESG
chmod 644 /etc/logrotate.conf
chmod 644 -R /etc/logrotate.d 
chmod a+x /etc/check_log

date                                               								>>    $ONLINE_UPDATE_MESG 
CP_RESER_BAK_RESULT_1=$(grep "CP_reset_bak_klipper_OK" 						$ONLINE_UPDATE_MESG)
CP_RESER_BAK_RESULT_2=$(grep "CP_reset_bak_flsun_func_OK" 					$ONLINE_UPDATE_MESG)
CP_RESER_BAK_RESULT_3=$(grep "CP_reset_bak_gcodes_OK" 						$ONLINE_UPDATE_MESG)
CP_RESER_BAK_RESULT_4=$(grep "CP_reset_bak_config_OK" 						$ONLINE_UPDATE_MESG)
CP_RESER_BAK_RESULT_5=$(grep "CP_reset_bak_klipper_config_OK" 				$ONLINE_UPDATE_MESG)
CP_RESER_BAK_RESULT_6=$(grep "CP_reset_bak_TUI_OK" 							$ONLINE_UPDATE_MESG)
#CP_RESER_BAK_RESULT_7=$(grep "CP_reset_bak_tuiconfig_OK" 					$ONLINE_UPDATE_MESG)

if [ $CP_RESER_BAK_RESULT_1 ] && [ $CP_RESER_BAK_RESULT_2 ] && [ $CP_RESER_BAK_RESULT_3 ] && [ $CP_RESER_BAK_RESULT_5 ] && [ $CP_RESER_BAK_RESULT_4 ] && [ $CP_RESER_BAK_RESULT_6 ]; then
	echo "ALL_RESET_BAK_FILE_CP_FINISH_OK"      	                                                            >>    $ONLINE_UPDATE_MESG 
else
	echo "ALL_RESET_BAK_FILE_CP_FINISH_NG"      	                                                            >>    $ONLINE_UPDATE_MESG
fi

RESULT_RESET_BAK_CP_FILE__ALL=$(grep   "ALL_RESET_BAK_FILE_CP_FINISH_OK"       $ONLINE_UPDATE_MESG)

#self
chmod 777 -R /home/pi/printer_data/gcodes/*.gcode
chmod 777 -R /home/pi/reset_bak/printer_data/gcodes/*.gcode
chmod 777 -R /home/pi/reset_bak

echo "80" > $UPDATE_PROGRESS
echo "80" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG
sync

if [ -f "/home/pi/flsun_func/plr.sh" ]; then
	rm -f /home/pi/flsun_func/plr.sh        && echo "RM_FILE_PLR_OK"      >>    $ONLINE_UPDATE_MESG
else
	echo "FILE_PLR_NOT_EXIT"             >> $ONLINE_UPDATE_MESG
fi

if [ -f "/home/pi/reset_bak/flsun_func/plr.sh" ]; then
	rm -f /home/pi/reset_bak/flsun_func/plr.sh        && echo "RM_FILE_RESET_PLR_OK"      >>    $ONLINE_UPDATE_MESG
else
	echo "FILE_RESET_PLR_NOT_EXIT"             >> $ONLINE_UPDATE_MESG
fi

if [ -f "/etc/init.d/adbd.sh" ]; then
	rm -rf /etc/init.d/adbd.sh        && echo "RM_FILE_ADBD_OK"      >>    $ONLINE_UPDATE_MESG
else
	echo "FILE_ADBD_NOT_EXIT"             >> $ONLINE_UPDATE_MESG
fi

chown -R root:root /etc
chmod -R o-w /etc

chown -R root:root /vendor
chown -R root:root /npu_arc


echo "90" > $UPDATE_PROGRESS
echo "90" >> $ONLINE_UPDATE_MESG
date >> $ONLINE_UPDATE_MESG

sync
if [ $RESULT_FILE_UPDATE_ALL ] && [ $RESULT_FILE_CHOWN_ALL ] && [ $RESULT_FILE_CHMOD_ALL ] && [ $RESULT_RESET_BAK_CP_FILE__ALL ]; then
	mv $UPDATE_BAK_DIR  $UPDATE_BAK_TMP_DIR      && echo "UPDATE_BAK_TMP_DIR_OK"        >> $ONLINE_UPDATE_MESG
	if [ "$(grep "UPDATE_BAK_TMP_DIR_OK" $ONLINE_UPDATE_MESG)" ] && [ ! -d $UPDATE_BAK_DIR ] && [ -d $UPDATE_BAK_CACHE_DIR ]; then
		mv $UPDATE_BAK_CACHE_DIR   $UPDATE_BAK_DIR     && echo "UPDATE_BAK_DIR_OK"        >> $ONLINE_UPDATE_MESG	
		if [ "$(grep "UPDATE_BAK_DIR_OK" $ONLINE_UPDATE_MESG)" ] && [ -d $UPDATE_BAK_DIR ]; then
			rm -rf $UPDATE_BAK_TMP_DIR   && echo "UPDATE_BAK_TMP_DIR_DEL_OK"        >> $ONLINE_UPDATE_MESG
			#self
			#cp -raf $FILE1_UPDATE_CONFIG $FILE1_UPDATE_LOCATION_CONFIG     && echo "CONFIG_BAK_FINISH"     	>>    $ONLINE_UPDATE_MESG
			#self
			echo "Successfully update files"        >>    $ONLINE_UPDATE_MESG
      		date                                               >>    $ONLINE_UPDATE_MESG 
			#sed -i '2c CurrentFirmwareVersion=4' $VERSION_CFG
			chmod +x /home/pi/upgrade/file_del.sh
			/home/pi/upgrade/file_del.sh 
			chmod +x /home/pi/upgrade/others/pushStreamer.sh
			/home/pi/upgrade/others/pushStreamer.sh
			
			chmod +x /home/pi/upgrade/others/klipper_cfg_check_install.sh
			/home/pi/upgrade/others/klipper_cfg_check_install.sh
			
			echo "100" > $UPDATE_PROGRESS
			echo "100" >> $ONLINE_UPDATE_MESG
			date >> $ONLINE_UPDATE_MESG
			
			touch $UPDATE_SUCCESS_FLAG
			#if pgrep -f "qt" > /dev/null; then
			#pkill -f "qt" &&  echo "qt process killed" >>   $ONLINE_UPDATE_MESG
			#fi
			#source /etc/profile
			#/home/pi/qt/out_linux/3d_print_gui &
			sync
		else
			mv $UPDATE_BAK_TMP_DIR  $UPDATE_BAK_DIR 
			echo "Restore the last backup file ok"        >> $ONLINE_UPDATE_MESG
			date                                               								>>    $ONLINE_UPDATE_MESG 
      		touch $UPDATE_FAIL_FLAG
			echo "Failed to update files"           	>>    $ONLINE_UPDATE_MESG
			sync
			exit
		fi
	elif [ ! -f $UPDATE_BAK_CACHE_DIR ] && [ -f $UPDATE_BAK_TMP_DIR ]; then
		mv $UPDATE_BAK_TMP_DIR $UPDATE_BAK_DIR 
		date                                               								>>    $ONLINE_UPDATE_MESG 
    	touch $UPDATE_FAIL_FLAG
		sync
		echo "Failed to update files"           		>>    $ONLINE_UPDATE_MESG
	else
		echo "Failed to rename the last backup file"       	>> $ONLINE_UPDATE_MESG
		date                                               								>>    $ONLINE_UPDATE_MESG 
     	touch $UPDATE_FAIL_FLAG
		echo "Failed to update files"          		>>    $ONLINE_UPDATE_MESG
		sync
		exit
	fi	
else 
	$RECOVERY_SCRIPT
	date                                               								>>    $ONLINE_UPDATE_MESG 
	touch $UPDATE_FAIL_FLAG
	echo "Failed to update files"           >>    $ONLINE_UPDATE_MESG
	sync
	exit
fi

