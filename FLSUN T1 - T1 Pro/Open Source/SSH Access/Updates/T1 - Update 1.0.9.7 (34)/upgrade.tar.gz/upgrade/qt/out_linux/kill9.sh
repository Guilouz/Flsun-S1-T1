#!/bin/sh

echo "Begin Shutdown Sle Software "

#遍历主控进程是否存在，存在就杀进程
for iii in `ps -ef|grep TUI|awk '{print $2}'`
do
	echo "killing the TUI process id  = ${iii}"
	kill -9 $iii
done

#遍历主控进程是否存在，存在就杀进程
#for jjj in `ps -ef|grep mqttSendUpgradeProgress|awk '{print $2}'`
#do
#	echo "killing the mqttSendUpgradeProgress process id  = ${jjj}"
#	kill -9 $jjj
#done

echo "Shutdown Sle Software Finish"
