#!/bin/bash
TIME_LAPSE_FOLDER=/home/pi/flsun_func/time_lapse
TMP_FILE=$TIME_LAPSE_FOLDER/tmp.txt
TIME_LAPSE_LOG=$TIME_LAPSE_FOLDER/time_lapse_log.txt
BMP_COUNT=$TIME_LAPSE_FOLDER/bmp_count
BMP_FOLDER=/home/pi/flsun_func/time_lapse/jpg
process_count=$(ps aux | grep -v grep | grep -c pushStream)

if [ "$process_count" -gt 0 ]; then
    /home/pi/klippy-env/bin/python $TIME_LAPSE_FOLDER/capturepicture
    echo "Yes camera process" >> $TIME_LAPSE_LOG   
    count=$(cat $BMP_COUNT)
    echo "count=$count" >> $TIME_LAPSE_LOG
    if [ -f "$BMP_FOLDER/photo${count}.jpg" ]; then
            count=$((count+1))
            count=$(printf "%04d" $count)
            echo $count > $BMP_COUNT
            echo "count+1" >> $TIME_LAPSE_LOG
            cp "$TIME_LAPSE_FOLDER/photo.jpg" "$BMP_FOLDER/photo${count}.jpg"
    else
        cp "$TIME_LAPSE_FOLDER/photo.jpg" "$BMP_FOLDER/photo${count}.jpg"
    fi    
           
else  
    echo "No camera process" >> $TIME_LAPSE_LOG
    exit
fi

