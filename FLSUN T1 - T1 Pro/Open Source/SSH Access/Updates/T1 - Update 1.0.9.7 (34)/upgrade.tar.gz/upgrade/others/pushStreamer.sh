#!/bin/bash

#处理遗留
service_video=video9-device.service
if [ -e "/etc/systemd/system/$service_video" ]; then
	systemctl stop $service_video
	systemctl disable $service_video
	rm -f /etc/systemd/system/$service_video
fi
#s1
program_s1=rkvenc_rtmp_mjpg_s1
if [ -e "/etc/systemd/system/$program_s1.service" ]; then
	systemctl stop $program_s1.service
	systemctl disable $program_s1.service
	rm -f /etc/systemd/system/$program_s1.service
	if [ -d "/home/pi/push_streamer/" ]; then
		rm -rf /home/pi/push_streamer/
	fi
fi
#t1
program_t1=rkvenc_rtmp_mjpg_t1
if [ -e "/etc/systemd/system/$program_t1.service" ]; then
	systemctl stop $program_t1.service
	systemctl disable $program_t1.service
	rm -f /etc/systemd/system/$program_t1.service
	if [ -d "/home/pi/push_streamer/" ]; then
		rm -rf /home/pi/push_streamer/
	fi
fi
#mjpg
service_mjpg=webcamd.service
if [ -e "/etc/systemd/system/$service_mjpg" ]; then
	systemctl stop $service_mjpg
	systemctl disable $service_mjpg
	rm -f /etc/systemd/system/$service_mjpg
	#if [ -d "/home/pi/mjpg-streamer/" ]; then
	#	rm -rf /home/pi/mjpg-streamer/
	#fi
fi

#关闭程序
push_program=pushStream
if [ -e "/etc/systemd/system/$push_program.service" ]; then
	systemctl stop $push_program.service
fi
#  	systemctl daemon-reload
#  	/sbin/ldconfig

#修改推流检查程序名
#s1
#sed -i 's/mjpg_streamer/pushStream/g' /home/pi/flsun_func/AI_detect/printing_run.sh
#sed -i 's/rkvenc_rtmp_mjpg_s1/pushStream/g' /home/pi/flsun_func/AI_detect/printing_run.sh
#t1
#sed -i 's/rkvenc_rtmp_mjpg_t1/pushStream/g' /home/pi/flsun_func/time_lapse/time_lapse.sh

#安装
pathCur=/home/pi/upgrade/others/
cd $pathCur
tar -zxvf push_streamer.tar.gz -C /home/pi/

#检测推流自启动
cd /home/pi/push_streamer/
chmod 755 $push_program
if [ -e "/etc/systemd/system/$push_program.service" ]; then
    echo "$push_program.service is exist"
else
#安装依赖库
    tar -zxvf libdatachannel.tar.gz -C /
fi
#安装自启动项
cd /home/pi/push_streamer/
cp $push_program.service /etc/systemd/system/
rm libdatachannel.tar.gz $push_program.service
cd /etc/systemd/system/
chown root:root $push_program.service
chmod 777 $push_program.service
systemctl enable $push_program.service
systemctl daemon-reload
/sbin/ldconfig
systemctl start $push_program.service

#检测video9监听服务
if [ -e "/etc/systemd/system/video9-device.service" ]; then
    echo "video9-device.service is exist"
else
    cd /home/pi/push_streamer/
    cp video9-device.service /etc/systemd/system/
    cd /etc/systemd/system/
    chown root:root video9-device.service
    chmod 777 video9-device.service
    systemctl enable video9-device.service
fi
cd /home/pi/push_streamer/
rm video9-device.service
systemctl daemon-reload
/sbin/ldconfig
systemctl start video9-device.service



