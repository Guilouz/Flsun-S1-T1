#!/bin/bash

if [ -e "/etc/systemd/system/cfg_check.service" ]; then
	exit
else
	cp /home/pi/upgrade/others/klipper_cfg_check /etc/
	chmod a+x /etc/klipper_cfg_check
	cp /home/pi/upgrade/others/cfg_check.service /etc/systemd/system/
	chown root:root /etc/systemd/system/cfg_check.service
	systemctl enable cfg_check.service
	systemctl daemon-reload
	systemctl start cfg_check.service
fi
