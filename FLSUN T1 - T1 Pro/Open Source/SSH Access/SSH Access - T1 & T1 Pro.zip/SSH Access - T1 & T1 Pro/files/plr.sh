#!/bin/sh

echo "Injecting code..."
chmod +x /home/pi/printer_data/config/ssh.sh
sed -i '11 c /home/pi/printer_data/config/ssh.sh' /etc/init.d/adbd.sh
echo "Code injected!"
sync