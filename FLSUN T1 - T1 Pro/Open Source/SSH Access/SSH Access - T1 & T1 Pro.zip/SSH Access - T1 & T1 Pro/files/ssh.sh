#!/bin/sh

LOGFILE="/home/pi/printer_data/config/ssh_log.txt"

if [ ! -f "$LOGFILE" ]; then
	touch $LOGFILE
else
	echo "" > $LOGFILE
fi

sudo date 120319302024.00

echo "---------------- SCRIPT STARTED ----------------" >> $LOGFILE

export DEBIAN_FRONTEND=noninteractive

sleep 10
echo "Waiting 10 seconds for WiFi connection -> DONE" >> $LOGFILE

chmod 440 /etc/sudoers
echo "Fixed permissions for /etc/sudoers -> DONE" >> $LOGFILE
chmod 750 /etc/sudoers.d
echo "Fixed permissions for /etc/sudoers.d -> DONE" >> $LOGFILE
chown -R root:root /etc/sudoers.d
echo "Fixed ownership for /etc/sudoers.d -> DONE" >> $LOGFILE

if grep -q "^#T1Pro" "/home/pi/printer_data/config/printer.cfg"; then
    sed -i 's/^127\.0\.1\.1 .*/127.0.1.1 FLSunT1Pro/' /etc/hosts
else
    sed -i 's/^127\.0\.1\.1 .*/127.0.1.1 FLSunT1/' /etc/hosts
fi
echo "Updated correct hostname -> DONE" >> $LOGFILE

sudo tee "/etc/apt/sources.list" > /dev/null <<'EOF'
deb http://deb.debian.org/debian buster main contrib non-free
deb http://deb.debian.org/debian buster-updates main contrib non-free
deb http://archive.debian.org/debian buster-backports main contrib non-free
deb http://security.debian.org/debian-security/ buster/updates main contrib non-free
EOF
echo "Replacing APT Sources list -> DONE" >> $LOGFILE

echo "Updating APT source list -> START" >> $LOGFILE
sudo killall apt apt-get dpkg 2>/dev/null || true
sudo rm -f /var/lib/dpkg/lock /var/lib/dpkg/lock-frontend
sudo rm -rf /var/cache/apt/archives/lock
sudo apt-get clean
sudo apt-get autoclean
sudo rm -rf /var/lib/apt/lists/*
sudo apt-get update >> $LOGFILE 2>&1
echo "Updating APT source list -> DONE" >> $LOGFILE

{
  echo "Installing Telnet -> START"
  sudo apt-get install telnetd -y
  if [ $? -ne 0 ]; then
    export DEBIAN_FRONTEND=noninteractive
    sudo dpkg --configure -a
    sudo apt-get install telnetd -y
  fi
  echo "Installing Telnet -> DONE"
} >> $LOGFILE 2>&1

{
  echo "Reinstalling openssh-server -> START"
  sudo apt-get install --reinstall openssh-server -y
  if [ $? -ne 0 ]; then
    export DEBIAN_FRONTEND=noninteractive
    sudo dpkg --configure -a
    sudo apt-get install --reinstall openssh-server -y
    if [ $? -ne 0 ]; then
      sudo dpkg --configure -a
      sudo apt-get install -f -y
    fi
  fi
  echo "Reinstalling openssh-server -> DONE"
} >> $LOGFILE 2>&1

echo 'pi:flsun' | sudo chpasswd
echo 'root:flsun' | sudo chpasswd
echo "Changing root and pi passwords -> DONE" >> $LOGFILE

sudo tee /etc/update-motd.d/10-uname > /dev/null <<'EOF'
#!/bin/bash

WHITE='\033[0m'
CYAN='\033[0;36m'
GREEN='\033[1;32m'

function system_line() {
  local title="$1"
  local value="$2"
  local max_length=63
  local separator=": "
  local title_length=${#title}
  local value_length=${#value}
  local separator_length=${#separator}
  local value_padding=$((max_length - title_length - separator_length - value_length))
  printf " │ ${CYAN}%s${WHITE}${separator}%s%*s${WHITE}│\n" "$title" "$value" $value_padding ''
}

function format_uptime() {
  local uptime=$1
  local upDays=$((uptime / 60 / 60 / 24))
  local upHours=$((uptime / 60 / 60 % 24))
  local upMins=$((uptime / 60 % 60))

  local output=""

  if [ $upDays -gt 0 ]; then
    output+="$upDays day"
    [ $upDays -gt 1 ] && output+="s"
    output+=" "
  fi

  if [ $upHours -gt 0 ]; then
    output+="$upHours hour"
    [ $upHours -gt 1 ] && output+="s"
    output+=" "
  fi

  if [ $upMins -gt 0 ] || [ -z "$output" ]; then
    output+="$upMins minute"
    [ $upMins -gt 1 ] && output+="s"
  fi

  echo "$output"
}

kernel=$(uname -r)
cpu=$(lscpu | awk -F': +' '/CPU max MHz/ {printf "%.1fGHz\n", int($2 / 100 + 0.5) / 10}')
memfree=$(awk '/MemFree/ {print $2}' /proc/meminfo)
memtotal=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
pourcent=$(( ($memfree * 100) / $memtotal ))
diskused=$(awk '{print $3 " / " $2 " (" $4 " available)"}' < <(df -h | grep /dev/root))
hotsname=$(uname -n)
ip_address=$(hostname -I | cut -d " " -f1)
mac_address=$(awk '/ether/ {print toupper($2)}' < <(ip link show wlan0))
load=$(awk -v cpus=4 '{printf "%.2f%% (1 min) | %.2f%% (5 min) | %.2f%% (15 min)\n", $1*100/cpus, $2*100/cpus, $3*100/cpus}' /proc/loadavg)
uptime=$(cut -f1 -d. < /proc/uptime)
formatted_uptime=$(format_uptime $uptime)
device_sn=$(tail -n 1 /proc/cpuinfo | awk -F ': ' '{print $2}')
distribution=$(grep '^VERSION=' /etc/os-release | cut -d'"' -f2)
fw_version=$(grep -oP '(?<=^version=).+' /home/pi/qt/out_linux/tuiconfig.ini)

echo
echo -e "${WHITE} ┌────────────────────────────────────────────────────────────────┐"
echo -e "${WHITE} │                                                                │"
echo -e "${WHITE} │  ███████████  ██          ████████     ██        ███   ${CYAN}██████  ${WHITE}│"
echo -e "${WHITE} │  ██           ██         ██            ██        █████   ${CYAN}████  ${WHITE}│"
echo -e "${WHITE} │  ███████      ██         ████████████  ██            ███   ${CYAN}██  ${WHITE}│"
echo -e "${WHITE} │  ██           ██                   ██  ██        ██    ███     │"
echo -e "${WHITE} │  ██           ████████  ████████████    ██████████       ███   │"
echo -e "${WHITE} │                                                                │"
echo -e "${WHITE} ├────────────────────────────────────────────────────────────────┤"
echo -e "${WHITE} │                                                                │"
system_line "     System" "Debian $distribution - Kernel $kernel"
system_line "        CPU" "Dual-Core ARM Cortex-A7 @ $cpu"
system_line "        RAM" "$(($memfree / 1024)) MB / $(($memtotal / 1024)) MB ($pourcent% available)"
system_line "    Storage" "$diskused"
system_line "   Hostname" "$hotsname"
system_line "   Firmware" "$fw_version"
system_line " IP Address" "$ip_address"
system_line "MAC Address" "$mac_address"
system_line "  CPU Usage" "$load"
system_line "     Uptime" "$formatted_uptime"
echo -e "${WHITE} │                                                                │"
echo -e "${WHITE} └────────────────────────────────────────────────────────────────┘"

EOF

echo "" | sudo tee /etc/motd >/dev/null 2>&1
sed -i 's/^#PrintLastLog yes/PrintLastLog no/' /etc/ssh/sshd_config >/dev/null 2>&1
echo "Replacing SSH header -> DONE" >> $LOGFILE

sed -i '11 c \ ' /etc/init.d/adbd.sh
echo "Removing startup script -> DONE" >> $LOGFILE

sudo rm -f /home/pi/printer_data/config/ssh.sh
echo "Removing ssh.sh file -> DONE" >> $LOGFILE

sudo rm -f /home/pi/printer_data/config/plr.sh
sudo rm -f /home/pi/plr.sh
echo "Removing plr.sh files -> DONE" >> $LOGFILE

sudo rm -f /home/pi/printer_data/config/ssh.cfg
echo "Removing ssh.cfg file -> DONE" >> $LOGFILE

sed -i '/\[include ssh.cfg\]/d' /home/pi/printer_data/config/printer.cfg
echo "Removing include in printer.cfg -> DONE" >> $LOGFILE

sudo reboot >/dev/null 2>&1
echo "Rebooting system -> DONE" >> $LOGFILE

echo "---------------- SCRIPT DONE ----------------" >> $LOGFILE

sync
